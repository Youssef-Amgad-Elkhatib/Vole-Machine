#include "A1_T4_S17,18_20230482_20230497_CPU.h"
#include <bits/stdc++.h>
using namespace std;

int CPU::hexCharToInt(char hexChar) {
    string hexString(1, hexChar);
    return stoi(hexString, nullptr, 16);
}

int CPU::hexToTwosComplement(const string &hexStr) {
    unsigned int num = 0;
    stringstream ss;
    ss << hex << hexStr;
    ss >> num;

    int bitWidth = 8;

    if (num & (1 << (bitWidth - 1))) {
        num = num - (1 << bitWidth);
    }

    return static_cast<int>(num);
}

string CPU::twosComplementToHex(int num) {
    int maxValue = (1 << 8) - 1;

    unsigned int twosComplementNum;
    if (num < 0) {
        twosComplementNum = (maxValue + 1) + num;
    } else {
        twosComplementNum = num;
    }

    stringstream ss;
    ss << hex << uppercase << setw(2) << setfill('0') << twosComplementNum;

    return ss.str();
}

void CPU::operate(RAM &m1, Registers &r1, int counter,bool step) {
    program_counter = counter;
    hexdisplay.clear();
    asciidisplay.clear();
    while(program_counter < m1.memory.size()) {
        string IR = m1.memory[program_counter] + m1.memory[program_counter + 1];

        // Add bounds checking
        if (program_counter + 1 >= m1.memory.size()) {
            break;
        }

        switch (IR[0]) {
            case '1': {  // LOAD from memory
                string xy = string(1, IR[2]) + string(1, IR[3]);
                int mem_addr = stoi(xy, nullptr, 16);
                if (mem_addr < m1.memory.size()) {
                    r1.memory[hexCharToInt(IR[1])] = m1.memory[mem_addr];
                }
                break;
            }
            case '2': {  // LOAD immediate
                string xy = string(1, IR[2]) + string(1, IR[3]);
                r1.memory[hexCharToInt(IR[1])] = xy;  // Load XY directly into register
                break;
            }
            case '3': {  // STORE
                string mem_cell_location = string(1, IR[2]) + string(1, IR[3]);
                int mem_index = stoi(mem_cell_location, nullptr, 16);
                int reg_index = hexCharToInt(IR[1]);

                if (mem_index < m1.memory.size() && reg_index < 16) {
                    m1.memory[mem_index] = r1.memory[reg_index];
                    if(mem_index == 0){
                        if(!step) {
                            hexdisplay.push_back(m1.memory[mem_index]);
                            asciidisplay.push_back(char(stoi(m1.memory[mem_index], nullptr, 16)));
                        }else{
                            cout << "hexa output: " << endl;
                            cout << m1.memory[mem_index] << endl;
                            cout << endl;
                            cout << "ASCII output: "<< endl;
                            cout << char(stoi(m1.memory[mem_index], nullptr, 16)) << endl;
                        }
                    }
                }
                break;
            }
            case '4': {  // MOVE
                int reg_r = hexCharToInt(IR[2]);
                int reg_s = hexCharToInt(IR[3]);

                if (reg_r < 16 && reg_s < 16) {
                    r1.memory[reg_s] = r1.memory[reg_r];
                }
                break;
            }
            case '5': {  // ADD two's complement
                int r_index = hexCharToInt(IR[1]);
                int s_index = hexCharToInt(IR[2]);
                int t_index = hexCharToInt(IR[3]);

                if (r_index < 16 && s_index < 16 && t_index < 16) {
                    int s_value = hexToTwosComplement(r1.memory[s_index]);
                    int t_value = hexToTwosComplement(r1.memory[t_index]);
                    int result = s_value + t_value;

                    r1.memory[r_index] = twosComplementToHex(result);
                }
                break;
            }
            case '6': {  // ADD floating-point
                int r_index = hexCharToInt(IR[1]);
                int s_index = hexCharToInt(IR[2]);
                int t_index = hexCharToInt(IR[3]);

                auto hex_to_float = [](string hex_string){
                    unsigned long value = stol(hex_string, nullptr, 16);
                    bitset<8> bits(value);
                    // Extract sign bit
                    unsigned int sign_bit = bits[7];
                    // Extract exponent bits
                    unsigned int exponent_bits = (bits[6] << 2) | (bits[5] << 1) | bits[4];
                    // Extract mantissa bits
                    unsigned int mantissa_bits = (bits[3] << 3) | (bits[2] << 2) | (bits[1] << 1) | bits[0];
                    // Compute exponent
                    int E = static_cast<int>(exponent_bits) - 4;
                    // Compute mantissa
                    float Mantissa = float(mantissa_bits) / 16.0;
                    // Compute sign
                    float sign = (sign_bit == 0) ? 1.0 : -1.0;
                    // Compute final value
                    float result = sign * Mantissa * pow(2, E);
                    return result;
                };

                float s_value = hex_to_float(r1.memory[s_index]);
                float t_value = hex_to_float(r1.memory[t_index]);
                float result = s_value + t_value;

                auto float_to_hex = [](float num) -> string{
                    // Handle zero case
                    if (num == 0) return "00";

                    // Get sign bit
                    unsigned int sign_bit = (num < 0) ? 1 : 0;
                    num = abs(num);

                    // Calculate exponent
                    int exponent = 0;
                    float normalized_num = num;

                    // Normalize number to be between 0.5 and 1
                    while (normalized_num > 1.0) {
                        normalized_num /= 2.0;
                        exponent++;
                    }
                    while (normalized_num < 0.5) {
                        normalized_num *= 2.0;
                        exponent--;
                    }

                    // Add bias (4) and clamp to valid range (0-7)
                    int E = exponent + 4;
                    if (E < 0) E = 0;
                    if (E > 7) E = 7;

                    // Calculate mantissa (4 bits)
                    float normalized = num / pow(2, E - 4);
                    int mantissa = round(normalized * 16);
                    if (mantissa >= 16) {
                        mantissa = 15;
                    }

                    // Combine bits into final value
                    unsigned int final_value = (sign_bit << 7) | (E << 4) | mantissa;

                    // Convert to hex string
                    stringstream ss;
                    ss << uppercase << hex << setw(2) << setfill('0') << final_value;
                    return ss.str();
                };
                string r = float_to_hex(result);
                r1.memory[r_index] = r;
                break;
            }
            case '7':{ // ORing
                int r_index = hexCharToInt(IR[1]);
                int s_index = hexCharToInt(IR[2]);
                int t_index = hexCharToInt(IR[3]);

                int s_value = stoi(r1.memory[s_index], nullptr, 16);
                int t_value = stoi(r1.memory[t_index], nullptr, 16);
                int result = s_value | t_value;

                stringstream ss;
                ss << uppercase << hex << setw(2) << setfill('0') << (result & 0xFF);
                r1.memory[r_index] = ss.str();
                break;
            }
            case '8': { // ANDing
                int r_index = hexCharToInt(IR[1]);
                int s_index = hexCharToInt(IR[2]);
                int t_index = hexCharToInt(IR[3]);

                int s_value = stoi(r1.memory[s_index], nullptr, 16);
                int t_value = stoi(r1.memory[t_index], nullptr, 16);
                int result = s_value & t_value;

                stringstream ss;
                ss << uppercase << hex << setw(2) << setfill('0') << (result & 0xFF);
                r1.memory[r_index] = ss.str();
                break;
            }
            case '9': { // XORing
                int r_index = hexCharToInt(IR[1]);
                int s_index = hexCharToInt(IR[2]);
                int t_index = hexCharToInt(IR[3]);

                int s_value = stoi(r1.memory[s_index], nullptr, 16);
                int t_value = stoi(r1.memory[t_index], nullptr, 16);
                int result = s_value ^ t_value;

                stringstream ss;
                ss << uppercase << hex << setw(2) << setfill('0') << (result & 0xFF);
                r1.memory[r_index] = ss.str();
                break;
            }
            case'A': {//ROTATE
                auto hexToBinary = [](const string &hex)-> string {
                    string binary;
                    for (char hexChar : hex) {
                        int value;
                        if (hexChar >= '0' && hexChar <= '9')
                            value = hexChar - '0';
                        else if (hexChar >= 'A' && hexChar <= 'F')
                            value = hexChar - 'A' + 10;
                        binary += bitset<4>(value).to_string();
                    }
                    return binary;
                };
                int r_index = hexCharToInt(IR[1]);
                string binary_value = hexToBinary(r1.memory[r_index]);
                int k = stoi(r1.memory[IR[3]], nullptr, 16);
                string result = binary_value.substr(k) + binary_value.substr(0, k);
                auto Binarytohex = [](const string &binary) -> string{
                    stringstream hexStream;
                    for (int i = 0; i < binary.size(); i += 4) {
                        string fourBits = binary.substr(i, 4);
                        int decimalValue = bitset<4>(fourBits).to_ulong();
                        if (decimalValue < 10)
                            hexStream << static_cast<char>('0' + decimalValue);
                        else
                            hexStream << static_cast<char>('A' + (decimalValue - 10));
                    }

                    return hexStream.str();
                };
                r1.memory[r_index] = Binarytohex(result);
                break;
            }
            case 'B': { // JUMP
                int reg_index = hexCharToInt(IR[1]);
                string jump_address = string(1, IR[2]) + string(1, IR[3]);

                if (reg_index >= 0 && reg_index < 16) {
                    if (r1.memory[reg_index] == r1.memory[0]) {
                        int new_pc = stoi(jump_address, nullptr, 16);
                        if (new_pc >= 0 && new_pc < m1.memory.size()) {
                            cout << endl;
                            cout<<"Current Instruction: "<<IR<<"   "<<"Current Counter: "<<program_counter<<endl;
                            m1.print();
                            r1.print();
                            program_counter = new_pc;

                            continue;
                        }
                    }
                }
                break;
            }
            case 'D': { // JUMP2
                int reg_index = hexCharToInt(IR[1]);
                string jump_address = string(1, IR[2]) + string(1, IR[3]);

                if (reg_index >= 0 && reg_index < 16) {
                    // Compare as two's complement integers
                    int reg_val = hexToTwosComplement(r1.memory[reg_index]);
                    int zero_val = hexToTwosComplement(r1.memory[0]);

                    if (reg_val > zero_val) {
                        int new_pc = stoi(jump_address, nullptr, 16);
                        if (new_pc >= 0 && new_pc < m1.memory.size()) {
                            cout << endl;
                            cout<<"Current Instruction: "<<IR<<"   "<<"Current Counter: "<<program_counter<<endl;
                            m1.print();
                            r1.print();
                            program_counter = new_pc;

                            continue;
                        }
                    }
                }
                break;
            }
            case 'C': {  // HALT
                if(step){
                    cout << endl;
                    cout<<"Current Instruction: "<<IR<<"   "<<"Current Counter: "<<program_counter<<endl;
                    m1.print();
                    r1.print();
                }
                return;
            }
            default:
                continue;
        }
        if(step){
            cout << endl;
            cout<<"Current Instruction: "<<IR<<"   "<<"Current Counter: "<<program_counter<<endl;
            m1.print();
            r1.print();
        }
        program_counter += 2;
    }
}

void CPU::display() {
    cout << "Hexa Display:" << endl;
    for(auto i : hexdisplay){
        cout << i << endl;
    }
    cout << endl;
    cout << "ASCII Display: " << endl;
    for(auto i : asciidisplay){
        cout << i;
    }
}






