#ifndef VOLE_MACHINE_CPU_H
#define VOLE_MACHINE_CPU_H
#include "A1_T4_S17,18_20230482_20230497_ram.h"
#include "A1_T4_S17,18_20230482_20230497_Registers.h"
#include <bits/stdc++.h>
using namespace std;

class CPU {
private:
    int program_counter = 1;
    vector<string> hexdisplay;
    vector<char> asciidisplay;
    int hexCharToInt(char hexChar);
    int hexToTwosComplement(const string& hexStr);
    string twosComplementToHex(int num);
public:
    void operate(RAM &m1, Registers &r1, int counter,bool step) ;
    void display();
};

#endif //VOLE_MACHINE_ALU_H