#ifndef VOLE_MACHINE_INSTRUCTIONS_H
#define VOLE_MACHINE_INSTRUCTIONS_H

#include <bits/stdc++.h>
#include "A1_T4_S17,18_20230482_20230497_ram.h"
#include "A1_T4_S17,18_20230482_20230497_Registers.h"
using namespace std;
class Instructions {
public:
    bool load_file(fstream& file, RAM& m1, int program_counter);

    bool isHexChar(char c) const;
    bool check_op(char c) const;
};

#endif // VOLE_MACHINE_INSTRUCTIONS_H