#ifndef RAM_H
#define RAM_H

#include "A1_T4_S17,18_20230482_20230497_Memory.h"

class RAM : public Memory {
public:
    RAM() {
        memory.resize(256, "00");  // Initialize 256 memory locations with "00"
    }

    void print() override;
    int get_size() const override { return 256; }
};

#endif