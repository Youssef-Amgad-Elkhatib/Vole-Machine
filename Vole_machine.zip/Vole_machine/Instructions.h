//
// Created by Youssef Elkhatib on 10/23/2024.
//

#ifndef VOLE_MACHINE_INSTRUCTIONS_H
#define VOLE_MACHINE_INSTRUCTIONS_H
#include <iostream>
#include <bits/stdc++.h>
#include "Memory.h"
using namespace std;

class Instructions {
public:
void load_file(fstream &file,Memory &m1);
};


#endif //VOLE_MACHINE_INSTRUCTIONS_H
